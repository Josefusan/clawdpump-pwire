#!/usr/bin/env node
// scripts/jev.mjs — Jev (TypeSafe AI System One, model "typesafe-ai/jev") decision helper for the PumpWire agent org.
// Zero dependencies. Node >= 18. Auth: AI_GATEWAY_API_KEY (Vercel AI Gateway) from env or ./.env.
//
//   node scripts/jev.mjs <pack> [--state-file F | --state "text or JSON" | --state - (stdin)] [--card T-012] [--exit N]
//                               [--q "question"] [--dry] [--quiet]
//   node scripts/jev.mjs raw --questions-file q.json [--state-file s.json]
//
// Packs: route · context · triage · stuck · done · risk · lesson · deadline · ask · raw
// Prints ONE compact JSON line: {"pack","action","pick","p","answers",...,"cost","ms"}
//
// Jev makes bounded decisions only. It never authorizes money, keys, mainnet or public actions.
// Fail-closed: any error prints {"action":"escalate"|"ask", "error": ...} with exit code 0,
// so callers never treat a failure as approval.

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const ORG = process.env.ORG_DIR || path.join(ROOT, '.org');
const ENDPOINT = process.env.JEV_ENDPOINT || 'https://ai-gateway.vercel.sh/v1/evaluate';
const MODEL = process.env.JEV_MODEL || 'typesafe-ai/jev';
const MAX_STATE_CHARS = +(process.env.JEV_MAX_STATE_CHARS || 24000);

// ---------- tiny helpers ----------
function loadDotEnv() {
  const f = path.join(ROOT, '.env');
  if (!fs.existsSync(f)) return;
  for (const line of fs.readFileSync(f, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
  }
}
function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const k = a.slice(2);
      const next = argv[i + 1];
      if (next === undefined || next.startsWith('--')) out[k] = true;
      else { out[k] = next; i++; }
    } else out._.push(a);
  }
  return out;
}
function readState(args) {
  let raw;
  if (args['state-file']) raw = fs.readFileSync(args['state-file'], 'utf8');
  else if (args.state === '-') raw = fs.readFileSync(0, 'utf8');   // explicit stdin only (never block on an open pipe)
  else if (typeof args.state === 'string') raw = args.state;
  else raw = '';
  let state;
  try { state = JSON.parse(raw); } catch { state = raw; }
  const s = typeof state === 'string' ? state : JSON.stringify(state);
  if (s.length > MAX_STATE_CHARS) {
    const head = Math.floor(MAX_STATE_CHARS / 3);
    const tail = MAX_STATE_CHARS - head;
    state = s.slice(0, head) + '\n…[truncated]…\n' + s.slice(-tail);
  }
  return state;
}
const pb = (a) => (a == null ? 0 : a.probability ?? a.noul ?? 0);            // boolean (AI SDK) or noul (TypeSafe native)
const top = (a) => (a == null ? [null, 0] : [a.choice, (a.probabilities || {})[a.choice] ?? 0]);
const sc = (a) => (a == null ? 0 : a.score ?? 0);
const r2 = (x) => Math.round(x * 100) / 100;
function compact(answers) {
  const o = {};
  for (const [k, a] of Object.entries(answers || {})) {
    if (a.type === 'choice') o[k] = { c: a.choice, p: r2(top(a)[1]) };
    else if (a.type === 'score') o[k] = r2(sc(a));
    else o[k] = r2(pb(a));
  }
  return o;
}

// ---------- context candidates (override with .org/context-index.json: {key: [pathOrSkill, description]}) ----------
const DEFAULT_CONTEXT = {
  interfaces:     ['docs/INTERFACES.md', 'package interfaces, TypeScript types, DB schema and API contracts between ingest, score, api, mcp and live'],
  product_spec:   ['docs/kit/01-PWIRE-Product-Spec.md', 'product spec: tools, prices, scoring factors and weights, data model, /live page contents'],
  hack_rules:     ['docs/kit/02-AnsemHack-Rules-and-Win-Plan.md', 'hackathon rules, judging criteria, day plan, stream pitch'],
  facts:          ['.org/FACTS.md (paste only the relevant lines)', 'verified endpoints, token mints, program IDs, package names and versions'],
  decisions:      ['.org/DECISIONS.md (paste only the relevant ADRs)', 'architecture decisions already made: libraries, storage, conventions, file locations'],
  skill_ingest:   ['skill: pumpwire-ingest', 'how pump.fun launches, trades and wallet funding are ingested'],
  skill_rug_risk: ['skill: pumpwire-rug-risk', 'how the rug-risk scoring engine and its reasons work'],
  skill_x402:     ['skill: pumpwire-x402-api', 'the paid HTTP API: x402 payments, pricing, payment verification'],
  skill_mcp:      ['skill: pumpwire-mcp', 'the MCP client package other agents install and how it pays'],
  skill_scout:    ['skill: pumpwire-scout', 'the Scout buyer/alert agent running on Hermes/ClawPump'],
  skill_bip:      ['skill: build-in-public', 'X posts, the public /live page, stream prep'],
};
function contextIndex() {
  const f = path.join(ORG, 'context-index.json');
  try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return DEFAULT_CONTEXT; }
}

// ---------- packs ----------
const TIERS = ['jev', 'ds_local', 'claude_haiku', 'claude_sonnet', 'claude_opus', 'human'];
const ROLE_FOR = { jev: 'jev ask', ds_local: 'ds-coder (local)', claude_haiku: 'builder haiku', claude_sonnet: 'builder sonnet', claude_opus: 'architect opus', human: 'Mises' };

const PACKS = {
  route: {
    main: 'tier', auto: ['dispatch'], lowConf: 'escalate',
    questions: () => ({
      tier: {
        type: 'choice',
        instructions: 'Which executor is the cheapest one that will complete this task card correctly on the first attempt?',
        criteria: {
          jev: 'A bounded yes/no, pick-one or rating decision over text already in hand. No writing and no code.',
          ds_local: 'Well-specified bulk work with a clear output format: fixtures, parsers from a given schema, SQL, labeling, docs, drafts, simple scripts. Low blast radius.',
          claude_haiku: 'A small mechanical code or config change in known files, under about 50 lines, with no design decisions.',
          claude_sonnet: 'Feature code with tests across a few files that follows an existing interface: ingest, API routes, MCP client, deploy scripts, UI page.',
          claude_opus: 'Architecture or interface design, security, payment verification, scoring design, debugging an unknown failure, or a final review.',
          human: 'Spending money, mainnet configuration, keys, public posts, merges to main, or a scope/priority call only the owner can make.',
        },
      },
      money_or_keys: { type: 'boolean', instructions: 'Does this task touch payment verification, wallets, keys, prices, spending caps, mainnet configuration or anything that moves funds?' },
      ambiguity: {
        type: 'score', instructions: 'How well specified is this task card?',
        criteria: ['fully specified: inputs, outputs and done-when are explicit', 'mostly specified: one or two small gaps', 'underspecified: key decisions are left open', 'unclear: the goal itself is unclear'],
      },
    }),
    act: (a) => {
      let [t, p] = top(a.tier);
      const money = pb(a.money_or_keys);
      if (t !== 'human' && p < 0.6) t = TIERS[Math.min(TIERS.indexOf(t) + 1, 4)];
      if (money >= 0.5 && TIERS.indexOf(t) < 3) t = 'claude_sonnet';
      const review = money >= 0.5 ? 'opus' : ['ds_local', 'claude_haiku', 'claude_sonnet'].includes(t) ? 'sonnet' : 'none';
      if (t === 'human') return { action: 'ask_human', pick: t, p };
      if (sc(a.ambiguity) >= 2) return { action: 'clarify_card', pick: t, p, role: ROLE_FOR[t], note: 'tighten inputs/done-when (or send to architect) before dispatch' };
      return { action: 'dispatch', pick: t, p, role: ROLE_FOR[t], review };
    },
  },

  context: {
    main: null, auto: [], lowConf: 'escalate',
    questions: () => Object.fromEntries(Object.entries(contextIndex()).map(([k, [, desc]]) => [k, {
      type: 'boolean',
      instructions: `Would an engineer need the ${desc} to complete this task card correctly?`,
    }])),
    act: (a) => {
      const idx = contextIndex();
      const include = Object.keys(idx).filter((k) => pb(a[k]) >= 0.4).map((k) => idx[k][0]);
      include.push('skill: clawrena-compliance'); // always
      return { action: 'include', pick: include, p: 1 };
    },
  },

  triage: {
    main: 'outcome', auto: ['to_review', 'review_scope', 'bounce'], lowConf: 'escalate',
    questions: () => ({
      outcome: {
        type: 'choice',
        instructions: "Classify this worker's result for the task card.",
        criteria: {
          done: 'The handoff shows every done-when criterion met, with evidence such as passing tests, counts or transaction signatures.',
          needs_fix: 'Work was done but a done-when criterion is unmet or a test fails, and the needed fix is concrete.',
          blocked: 'The worker could not proceed because of a missing dependency, credential, decision, or an external outage.',
          needs_human: 'Continuing requires approval, money, a public action, or an owner decision.',
        },
      },
      evidence: { type: 'boolean', instructions: 'Does the handoff cite concrete evidence (test output, counts, file paths, tx signatures) rather than only claiming success?' },
      scope_creep: { type: 'boolean', instructions: "Did the worker change things outside the card's stated scope or files?" },
    }),
    act: (a, ctx) => {
      const [o, p] = top(a.outcome);
      const ev = pb(a.evidence), creep = pb(a.scope_creep);
      if (ctx.exit !== undefined && ctx.exit !== 0 && o === 'done') return { action: 'escalate', pick: o, p, note: 'claims done but the process exited non-zero' };
      if (o === 'done' && p >= 0.8 && ev >= 0.7) return { action: creep >= 0.6 ? 'review_scope' : 'to_review', pick: o, p };
      if (o === 'needs_fix' && p >= 0.7) return { action: 'bounce', pick: o, p };
      if (o === 'blocked' && p >= 0.7) return { action: 'unblock', pick: o, p };
      if (o === 'needs_human' && p >= 0.6) return { action: 'ask_human', pick: o, p };
      return { action: 'escalate', pick: o, p, note: 'read the handoff yourself' };
    },
  },

  stuck: {
    main: 'cause', auto: ['retry_once'], lowConf: 'escalate',
    questions: () => ({
      stuck: { type: 'boolean', instructions: 'Is this work stuck: the same error or approach repeating across attempts without measurable progress?' },
      cause: {
        type: 'choice', instructions: 'What is the most likely cause of the lack of progress?',
        criteria: {
          spec: 'The task card is unclear, contradictory, or asks for the wrong thing.',
          capability: 'The task needs a stronger model or a human expert.',
          environment: 'A missing dependency, credential, rate limit or infrastructure failure.',
          flaky: 'A nondeterministic test or network flakiness.',
        },
      },
    }),
    act: (a) => {
      const s = pb(a.stuck);
      if (s < 0.7) return { action: 'continue', pick: 'progressing', p: r2(1 - s) };
      const [c, p] = top(a.cause);
      return { action: { spec: 'rewrite_card', capability: 'escalate_tier', environment: 'fix_env', flaky: 'retry_once' }[c] || 'escalate', pick: c, p };
    },
  },

  done: {
    main: null, auto: ['pass'], lowConf: 'escalate',
    questions: () => ({
      met: {
        type: 'boolean', instructions: 'Does the evidence show that the criterion is fully met?',
        criteria: { true: 'The evidence directly demonstrates every part of the criterion.', false: 'Any part of the criterion is unmet, unproven, or contradicted by the evidence.' },
      },
    }),
    act: (a) => {
      const p = pb(a.met);
      return { action: p >= 0.85 ? 'pass' : p <= 0.3 ? 'fail' : 'escalate', pick: 'met', p };
    },
  },

  risk: {
    main: 'cls', auto: ['allow'], lowConf: 'ask',
    questions: () => ({
      cls: {
        type: 'choice', instructions: 'Classify what this shell command does.',
        criteria: {
          read_only: 'Only reads or lists: status, logs, search, diffs, printing non-secret files, GET requests to our own health or stats endpoints.',
          reversible_write: 'Writes project files, installs packages, commits or pushes a card/dev branch, creates a worktree, starts or restarts a devnet service. Undoable with git or a restart.',
          destructive: 'Deletes data, files or branches, force-pushes, drops or deletes database rows, rewrites history, or stops production services.',
          money_or_keys: 'Reads or prints secrets, .env files or keypairs, signs or sends a Solana transaction, or changes payTo, prices, spending caps or mainnet configuration.',
          public: 'Publishes something: posts, npm publish, making a repository public, listing a service, messaging people.',
        },
      },
      touches_prod: { type: 'boolean', instructions: 'Does the command change the main branch, the ~/pumpwire main checkout, the live database, or a mainnet (non-devnet) service?' },
    }),
    act: (a) => {
      const [c, p] = top(a.cls);
      const prod = pb(a.touches_prod);
      if (c === 'money_or_keys' || c === 'public') return { action: 'deny', pick: c, p };
      if (prod >= 0.5) return { action: 'deny', pick: 'touches_prod', p: prod };
      if ((c === 'read_only' || c === 'reversible_write') && p >= 0.7) return { action: 'allow', pick: c, p };
      return { action: 'ask', pick: c, p };
    },
  },

  lesson: {
    main: 'kind', auto: ['promote'], lowConf: 'drop',
    questions: () => ({
      durable: { type: 'boolean', instructions: 'Will this lesson still be true and useful for later tasks in this project, rather than being a one-off detail?' },
      kind: {
        type: 'choice', instructions: 'What kind of knowledge is this?',
        criteria: {
          fact: 'A verified fact about an endpoint, mint, library, limit or environment.',
          decision: 'A choice the team made that others must follow.',
          procedure: 'A repeatable sequence of steps that worked.',
          noise: 'Status chatter, a transient error, or something already obvious.',
        },
      },
    }),
    act: (a) => {
      const d = pb(a.durable);
      const [k, p] = top(a.kind);
      if (k === 'noise' || d < 0.6) return { action: 'drop', pick: k, p };
      return { action: 'promote', pick: k, p, to: { fact: '.org/FACTS.md', decision: '.org/DECISIONS.md', procedure: '.org/playbooks/' }[k] };
    },
  },

  deadline: {
    main: null, auto: [], lowConf: 'watch',
    questions: () => ({
      risk: {
        type: 'score', instructions: 'Given this state, how likely is the team to have the paid rug_risk_score API live on mainnet by the mainnet target time?',
        criteria: ['on track with buffer', 'on track with no buffer', 'at risk: one more slip misses the target', 'will miss the target without cutting scope'],
      },
      loop_threatened: { type: 'boolean', instructions: 'Is any part of the core paid-call loop (ingest, score, x402 API, MCP client, /live) blocked or failing?' },
    }),
    act: (a) => {
      const r = sc(a.risk), t = pb(a.loop_threatened);
      if (r >= 2 || t >= 0.6) return { action: 'cut_scope', pick: r2(r), p: r2(t) };
      if (r >= 1.5) return { action: 'watch', pick: r2(r), p: r2(t) };
      return { action: 'on_track', pick: r2(r), p: r2(t) };
    },
  },

  ask: {
    main: null, auto: [], lowConf: 'unsure',
    questions: (args) => {
      if (typeof args.q !== 'string') throw new Error('ask needs --q "question"');
      const q = { type: 'boolean', instructions: args.q };
      if (typeof args.true === 'string' && typeof args.false === 'string') q.criteria = { true: args.true, false: args.false };
      return { answer: q };
    },
    act: (a) => {
      const p = pb(a.answer);
      return { action: p >= 0.8 ? 'yes' : p <= 0.2 ? 'no' : 'unsure', pick: 'answer', p };
    },
  },

  raw: {
    main: null, auto: [], lowConf: 'escalate',
    questions: (args) => JSON.parse(fs.readFileSync(args['questions-file'], 'utf8')),
    act: () => ({ action: 'raw', pick: null, p: null }),
  },
};

// ---------- gateway call ----------
async function evaluate(state, questions) {
  const key = process.env.AI_GATEWAY_API_KEY;
  if (!key) throw new Error('AI_GATEWAY_API_KEY missing (set it in ~/pumpwire-control/.env)');
  const body = { model: MODEL, state, questions, providerOptions: { gateway: { zeroDataRetention: true } } };
  let lastErr;
  for (let attempt = 0; attempt < 2; attempt++) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), +(process.env.JEV_TIMEOUT_MS || 8000));
    try {
      const r = await fetch(ENDPOINT, {
        method: 'POST',
        headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: ctrl.signal,
      });
      const j = await r.json().catch(() => ({}));
      if (r.ok) return j;
      lastErr = new Error(`HTTP ${r.status}: ${j.message || j.error?.message || JSON.stringify(j).slice(0, 200)}`);
      if (r.status < 500 && r.status !== 429) break; // don't retry client errors
    } catch (e) {
      lastErr = e;
    } finally {
      clearTimeout(timer);
    }
    await new Promise((res) => setTimeout(res, 400));
  }
  throw lastErr;
}

function ledger(line) {
  try {
    fs.mkdirSync(ORG, { recursive: true });
    fs.appendFileSync(path.join(ORG, 'jev-ledger.jsonl'), JSON.stringify(line) + '\n');
  } catch { /* ledger is best-effort */ }
}

// ---------- main ----------
async function main() {
  loadDotEnv();
  const args = parseArgs(process.argv.slice(2));
  const packName = args._[0];
  const pack = PACKS[packName];
  if (!pack) {
    console.error(`usage: jev.mjs <${Object.keys(PACKS).join('|')}> [--state-file F | --state S | --state -] [--card T-xxx] [--exit N] [--q "..."] [--dry]`);
    process.exit(2);
  }
  const ctx = { card: typeof args.card === 'string' ? args.card : undefined, exit: args.exit !== undefined ? Number(args.exit) : undefined };
  const t0 = Date.now();
  let out;
  try {
    const questions = pack.questions(args);
    const state = readState(args);
    if (args.dry) {
      console.log(JSON.stringify({ endpoint: ENDPOINT, model: MODEL, state, questions }, null, 2));
      return;
    }
    const j = await evaluate(state, questions);
    const answers = j.answers || {};
    const conf = j.providerMetadata?.typesafe?.confidence || j.provider_metadata?.typesafe?.confidence || null;
    let res = pack.act(answers, ctx);
    // Low native confidence on the main question downgrades any automatic action.
    if (pack.main && conf && typeof conf[pack.main] === 'number' && conf[pack.main] < 0.5 && pack.auto.includes(res.action)) {
      res = { ...res, action: pack.lowConf, note: `low confidence ${r2(conf[pack.main])} on ${pack.main}` };
    }
    const cost = Number(j.providerMetadata?.gateway?.cost ?? j.provider_metadata?.gateway?.cost ?? 0);
    out = { pack: packName, card: ctx.card, ...res, p: typeof res.p === 'number' ? r2(res.p) : res.p, answers: compact(answers), conf, cost, ms: Date.now() - t0 };
  } catch (e) {
    out = { pack: packName, card: ctx.card, action: pack.lowConf === 'ask' ? 'ask' : 'escalate', error: String(e.message || e).slice(0, 300), ms: Date.now() - t0 };
  }
  ledger({ ts: new Date().toISOString(), ...out });
  console.log(JSON.stringify(out));
}

main();

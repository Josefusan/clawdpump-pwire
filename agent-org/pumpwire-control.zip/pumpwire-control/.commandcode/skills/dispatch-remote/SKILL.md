---
name: dispatch-remote
description: How the Principal writes task cards and briefs, dispatches work to VPS Claude Code / Hermes workers or local subagents, collects results, acts on triage verdicts, runs reviews, merges to dev and deploys devnet. Use whenever you create, dispatch, collect, review or merge a card.
---

# Dispatch, collect, review, merge

## 1. Card format (`.org/TASKS.md`)
```
### T-012 rug_risk_score v0
status: TODO | DOING | REVIEW | BLOCKED | DONE
lane: A | B | ops | ds | docs
role: builder · model: sonnet · reviewer: opus
deps: T-002, T-007
due: Thu 02:00 CT
done when: <observable, testable criteria — the reviewer checks each item>
context: <paths / skill names from `jev context`>
notes: <attempt history, one line per attempt>
```
Rules: ≤ 3 h of work per card. "done when" must be checkable by a command or a count. Split anything bigger.

## 2. Brief template (`.org/briefs/T-xxx.md`, ≤ 1,200 words)
```
# <CARD> — <title>
Goal: <one sentence: what exists after this card that didn't before>
Done when:
- <criterion 1 — command that proves it>
- <criterion 2>
Scope: touch only <dirs/files>. Out of scope: <explicit list>.
Read first: <paths from `jev context`, e.g. docs/INTERFACES.md §Score, docs/kit/01-PWIRE-Product-Spec.md §Rug-risk scoring>
Load skills: clawrena-compliance, <others>
Facts you need (verbatim from .org/FACTS.md): <only the lines needed>
Decisions to follow: <ADR ids + one line each>
Prior attempts: <from bin/pw-recall, or "none">
Constraints: <perf, deps, env var names>
Hand off with the HANDOFF block from your role prompt.
```
Never paste a spec, skill or large file. Workers load them by path.

## 3. Dispatch
| Work | Command |
|---|---|
| VPS Claude worker | `bin/pw-dispatch T-012 builder` (defaults: architect opus/30 · reviewer opus/20 · builder sonnet/50 · ops sonnet/25 · ds deepseek/40) |
| Override model / turns | `bin/pw-dispatch T-015 builder haiku 20` |
| Fix after a bounce (keeps the worker's context) | write a fix brief to `.org/briefs/T-012.md` listing the numbered fixes → `bin/pw-dispatch T-012 builder sonnet 25 --resume` |
| Review | write `.org/briefs/T-012-R.md` (card id, done-when, "review card/T-012 against origin/dev", payment checklist if relevant) → `bin/pw-dispatch T-012-R reviewer` (use `reviewer sonnet` for non-money cards) |
| Hermes config task | `bin/pw-dispatch T-019 seller` / `bin/pw-dispatch T-016 scout` |
| Local DeepSeek subagent | delegate by name: researcher, ds-coder, drafter, scribe. Several in one turn = parallel |
| Wait | `bin/pw-wait` (≤ 110 s per call; repeat) |

Before dispatching: card status → DOING; deps are DONE (merged to dev); no other running card touches the same files.

## 4. Collect → act on the verdict
`bin/pw-collect T-012` prints the handoff, metrics and `suggested: <action>`.

| Suggested | Do this |
|---|---|
| `to_review` | status REVIEW → write `T-012-R` brief → dispatch reviewer (opus if money/security) |
| `review_scope` | as `to_review`, and tell the reviewer to check the out-of-scope changes explicitly |
| `merge` (reviewer APPROVE) | `bin/pw-merge T-012` → status DONE → if it's a service, `bin/pw-deploy-devnet` |
| `bounce` | write fix brief with the reviewer's numbered fixes → `--resume` the builder. 2nd bounce on the same card → `jev stuck` |
| `unblock` | fix the dependency/credential yourself if reversible, else A-xxx to Mises; status BLOCKED |
| `ask_human` | A-xxx in APPROVALS.md with the exact command; tell Mises |
| `escalate` | read `.org/handoffs/T-012.md` and, if needed, `jq '.result' .org/runs/T-012.json` / stderr tail; decide; log an override line if you disagree with Jev |

Merge conflicts from `pw-merge` (exit 5): `--resume` the builder with "rebase card/T-xxx onto origin/dev, keep both changes, rerun tests". Test failure after merge (exit 6): nothing was pushed; bounce with the failing test output.

## 5. Parallel lanes (keep both busy)
- Lane A (data): T-004 ingest → T-005 enrich → T-010 score → T-014 backtest
- Lane B (money): T-006 API/x402 → T-011 MCP → T-012 devnet paid loop → T-016/T-019 Scout/Seller
- Side lanes: ops (T-009, T-017), ds-coder (T-008, T-013), drafter (T-015), researcher (T-003, any VERIFY)

## 6. Devnet vs mainnet
- You may: merge to dev, deploy devnet (`bin/pw-deploy-devnet`), restart `*-devnet` services via ops cards.
- Mises does: merge dev → main, run `scripts/cutover-mainnet.sh`, fund wallets, publish. You prepare each as an A-xxx with the exact command.

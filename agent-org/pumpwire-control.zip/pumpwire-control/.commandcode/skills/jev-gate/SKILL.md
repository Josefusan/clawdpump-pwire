---
name: jev-gate
description: How to use Jev (TypeSafe System One model typesafe-ai/jev via Vercel AI Gateway) through scripts/jev.mjs for routing, triage, stuck detection, context selection, gate checks, command risk, lesson filtering and deadline risk. Use before any bounded judgment instead of reasoning it out in tokens.
---

# Jev decision layer

Jev returns typed answers (`choice`, `score`, `boolean`) with probabilities. ~0.1–0.5 s, ~$0.042 per million input tokens, output free. It cannot write text or code, and it can only pick from the options you give it.

## Call it
```
node scripts/jev.mjs <pack> --state-file <file>     # file may be text or JSON
node scripts/jev.mjs <pack> --state "<text or JSON>"
node scripts/jev.mjs ask --q "Is the ingest lag under 5 seconds?" --state "$(bin/pw-status)"
node scripts/jev.mjs <pack> --state "..." --dry       # print the request, no call
```
Output is one JSON line; act on `.action`. Every call is appended to `.org/jev-ledger.jsonl` with cost and latency.

## Packs and thresholds (built into jev.mjs)
| Pack | Question(s) | Auto-act rule |
|---|---|---|
| route | tier choice (jev / ds_local / claude_haiku / claude_sonnet / claude_opus / human) + money_or_keys + ambiguity | top p < 0.6 → one tier up; money ≥ 0.5 → at least sonnet + opus review; ambiguity ≥ 2 → `clarify_card` |
| context | one boolean per candidate doc/skill (`.org/context-index.json` overrides the defaults) | include if p ≥ 0.4; compliance skill always |
| triage | outcome choice + evidence + scope_creep | `to_review` only if done p ≥ 0.8 AND evidence ≥ 0.7 AND exit 0 |
| stuck | stuck boolean + cause choice | stuck ≥ 0.7 → rewrite_card / escalate_tier / fix_env / retry_once |
| done | criterion met? | pass ≥ 0.85 · fail ≤ 0.3 · else escalate |
| risk | command class + touches_prod | money/keys/public/prod → deny; read-only or reversible ≥ 0.7 → allow; else ask |
| lesson | durable + kind | promote fact/decision/procedure if durable ≥ 0.6 |
| deadline | risk score 0–3 + loop_threatened | ≥ 2 or threatened ≥ 0.6 → `cut_scope` |
| ask | your boolean | yes ≥ 0.8 · no ≤ 0.2 · else unsure |

Low native confidence (< 0.5) on the main question turns any automatic action into `escalate`/`ask`. Errors return `escalate`/`ask` — never approval.

## Where Jev sits in the loop
1. Guard hook: every non-trivial shell command → `risk` (after the deterministic deny list).
2. Planning: `route` + `context` per card → role, model, brief references.
3. Collection: `pw-collect` runs `triage` automatically.
4. Loops: second failure on a card → `stuck`.
5. Gates: deterministic check first, then `done` on `{criterion, evidence}`.
6. Checkpoints: `deadline` on STATE.md; scribe runs `lesson` on each candidate lesson.

## Never ask Jev
- Whether to spend money, touch keys, deploy mainnet, publish, or merge to main — those are rules + Mises.
- Anything that needs a new option it wasn't given, or free-form text.
- Security sign-off on payment code — that is an opus reviewer.

## Writing good questions (for `ask` and new packs)
- One factor per question; combine answers in code.
- Criteria describe the case in words ("blocking with no workaround"), not labels ("high").
- State holds only the decision-relevant fields; trim logs to the tail.
- If you override Jev, log it: `echo '{"ts":"…","override":"triage","card":"T-012","jev":"to_review","you":"bounce","why":"tests skipped"}' >> .org/jev-ledger.jsonl`

## Product-side use (stretch, after G5)
- Scout spend gate: before paying $0.01 for a score, `ask` "Is this launch worth scoring?" over first-2-minute stats — an agent that decides in 0.3 s for ~$0.00001 whether to spend $0.01 is a clean demo line.
- Metadata copycat flag (5 pts in the score): `choice` over trending names/tickers. Keep the core score deterministic.

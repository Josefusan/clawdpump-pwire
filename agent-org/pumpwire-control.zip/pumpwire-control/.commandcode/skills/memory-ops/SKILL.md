---
name: memory-ops
description: The PumpWire org memory system - working state, episodic logs, semantic facts/decisions, procedural playbooks and skills - with file formats, write ownership, recall, the consolidation procedure and the restart protocol. Use at checkpoints, after incidents, before retrying failed work, and after any restart or compaction.
---

# Org memory

## Files and owners
| File | Tier | Owner | Format |
|---|---|---|---|
| `AGENTS.md` | working (static) | Mises | frozen during sprint |
| `.org/STATE.md` | working | Principal (scribe proposes `.org/STATE.next.md`) | ≤ 60 lines, template below |
| `.org/TASKS.md` | working | Principal | cards (skill dispatch-remote §1) |
| `.org/APPROVALS.md` | working | Principal writes, Mises changes `status:` | `## A-xxx` blocks |
| `.org/episodes/YYYY-MM-DD.jsonl` | episodic | bin scripts + Principal | one JSON object per line |
| `.org/handoffs/T-xxx.md` | episodic | pw-collect | worker HANDOFF block |
| `.org/runs/T-xxx.json` | episodic | pw-collect | raw worker output (read only on escalate) |
| `.org/ledger.csv` | episodic | pw-collect | cost/tokens per run |
| `.org/jev-ledger.jsonl` | episodic | jev.mjs + overrides | one decision per line |
| `.org/FACTS.md` | semantic | scribe / Principal | `- [VERIFIED|VERIFY] <fact> — <source> — <date>` |
| `.org/DECISIONS.md` | semantic | Principal | `D-xxx <date> <decision> — why — who` |
| `docs/INTERFACES.md`, `docs/adr/` (repo) | semantic | architect | contracts |
| `.org/playbooks/<slug>.md` | procedural | scribe | ≤ 30 lines: when, steps, verify, gotchas |
| skills (`.commandcode/skills`, repo `.claude/skills`, `~/.hermes/skills`) | procedural | Principal applies patches | SKILL.md |

## Episode line schema
```json
{"ts":"2026-10-01T03:12:00Z","agent":"builder","card":"T-010","event":"result|dispatch|merged_to_dev|deploy_devnet|gate|incident|lesson|decision|approval",
 "status":"done","exit":0,"secs":1420,"turns":31,"cost":0.84,"in_tok":210000,"out_tok":9000,"session_id":"…","triage":"to_review",
 "note":"…","lesson":"…"}
```
Add your own lines for gates, incidents and lessons:
`echo '{"ts":"'$(date -u +%FT%TZ)'","agent":"principal","card":"T-006","event":"lesson","lesson":"x402 devnet facilitator rejects …"}' >> .org/episodes/$(date +%F).jsonl`

## STATE.md template (rewrite, don't append)
```
# STATE — <day hh:mm CT>
clock: T0 Wed 17:00 · mainnet target Thu 12:00 · hard stop Thu 21:30
budget: SPRINT_BUDGET_USD=75 · burn $<x> workers + $<y> jev
phase: <W0|W1|NIGHT|W3|W4|STRETCH> · next gate: <Gx> ETA <time>
gates: G1 <✅|⏳|☐> G2 … G3 … G4 … G5 …
running: <card role elapsed>, …
blocked: <card: reason> | none
waiting on Mises: <A-xxx …> | none
services: <name status> …
facts in flight: <VERIFY items still open>
risks: <≤ 3 lines>
next: <≤ 5 card ids in order>
```

## Recall
`bin/pw-recall <card|component|error text>` before re-dispatching a failed card or starting a card on a component with history. Never retry an approach that already failed without writing what's different in the brief's "Prior attempts".

## Consolidation (scribe, at each checkpoint)
1. Read episodes and handoffs since `.org/.last_consolidation` (use `jq -c 'select(.ts > "<last>")'`).
2. Collect candidate lessons: every `lesson:` field that isn't "none", every incident, every Jev override.
3. For each: `node scripts/jev.mjs lesson --state "<lesson + card + outcome>"`.
   - `promote` + fact → append to FACTS.md (VERIFY unless a primary source is cited).
   - `promote` + decision → return ADR-lite line for the Principal.
   - `promote` + procedure → new/updated playbook; if the same playbook was used successfully twice, write `.org/skill-patches/<skill>.md` with the proposed SKILL.md addition.
   - `drop` → nothing.
4. Write `.org/STATE.next.md` (≤ 60 lines) from the template; drop everything already DONE except gate results.
5. Summarize burn from `ledger.csv` and `jev-ledger.jsonl`.
6. `date -u +%FT%TZ > .org/.last_consolidation`.
The Principal then: `mv .org/STATE.next.md .org/STATE.md`, adds decisions, applies skill patches via a small card on dev, commits `.org`.

## Restart protocol (new session, crash, compaction)
1. `bin/pw-boot` — AGENTS.md is already loaded; STATE.md must be enough to resume.
2. Reconcile: every DOING card must be either running (`bin/pw-status` runs) or finished (collect it). DOING with neither → re-dispatch with `--resume` if a session_id exists in `.org/runs/`, else fresh.
3. Check `.org/APPROVALS.md` for anything Mises resolved while you were down.
4. Continue the control loop. Log `{"event":"incident","note":"principal restart"}`.

## Hermes memory hygiene
Hermes writes its own skills and memories. At each checkpoint: `ssh pw 'ls -t ~/.hermes/skills | head -5'`. Anything new that touches spending, posting or trading → review against clawrena-compliance; disable with `hermes skills disable <name>` via an A-xxx if it conflicts.

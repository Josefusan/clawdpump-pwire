#!/usr/bin/env bash
# PreToolUse guard for the Principal's shell tool (and its subagents).
# Order: 1) hard deny (regex, never overridable)  2) fast allow (known read-only / org scripts)  3) Jev risk pack.
# Block = exit 2 with the reason on stderr. Allow = exit 0.
# GUARD_FAIL_MODE=open (default) lets a command through if Jev is unreachable, because step 1 already
# covers money/keys/public/main deterministically. Set GUARD_FAIL_MODE=closed to block instead.
set -uo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
IN="$(cat)"
CMD="$(printf '%s' "$IN" | jq -r '.tool_input.command // .input.command // .toolInput.command // .arguments.command // .params.command // .command // empty' 2>/dev/null)"
[ -z "$CMD" ] && CMD="$IN"
mkdir -p "$DIR/.org"
log()   { printf '%s\t%s\t%s\n' "$(date -u +%FT%TZ)" "$1" "$(printf '%s' "$CMD" | tr '\n' ' ' | cut -c1-300)" >> "$DIR/.org/guard.log"; }
block() { log "BLOCK:$1"; echo "BLOCKED by guard ($1). Do not retry or work around this. If it is truly needed, add an A-xxx entry to .org/APPROVALS.md with the exact command for Mises to run himself." >&2; exit 2; }

# 1) Hard deny — money, keys, secrets, public actions, main branch, prod data.
DENY="$(cat <<'RE'
\.env($|[[:space:]"'/;|&)])|\.config/pumpwire|\.pumpwire-agents\.env|id_(rsa|ed25519)|keypair[^[:space:]]*\.json|solana-keygen|seed[ _-]?phrase|mnemonic|private[_ -]?key|(^|[;&|[:space:]'"])(env|printenv|set)([[:space:]'"]*$|[[:space:]'"]*[;&|])|solana[[:space:]]+(transfer|pay)|spl-token[[:space:]]+(transfer|burn|close)|git[[:space:]]+push[^;&|]*[[:space:]](--force|-f)([[:space:]]|$)|git[[:space:]]+push[^;&|]*[[:space:]:]main([[:space:]'"]|$)|npm[[:space:]]+publish|gh[[:space:]]+repo[[:space:]]+(edit|create)[^;&|]*public|--visibility[[:space:]=]+public|cutover-mainnet|pm2[[:space:]]+(delete|kill)|rm[[:space:]]+-[a-z]*r[a-z]*[[:space:]]+(/|~|\$HOME|[^[:space:]]*pumpwire-data)|drop[[:space:]]+table|delete[[:space:]]+from|chmod[[:space:]]+777|guard\.sh|commandcode/settings
RE
)"
printf '%s' "$CMD" | grep -Eiq -- "$DENY"; rc=$?
[ "$rc" -eq 0 ] && block "hard-deny rule"
[ "$rc" -gt 1 ] && block "deny-regex error (fail closed)"

# 2) Fast allow — single, unchained read-only commands and our own control scripts.
if ! printf '%s' "$CMD" | grep -Eq '[;&|><`]|\$\('; then
  if printf '%s' "$CMD" | grep -Eq '^[[:space:]]*(bash[[:space:]]+)?(bin/pw-(boot|status|wait|collect|recall|doctor|dispatch|merge|deploy-devnet|sync-vps)|\./bin/pw-[a-z-]+|node[[:space:]]+scripts/jev\.mjs|ls|cat|head|tail|wc|rg|grep|jq|date|pwd|echo|which|tree|du|df|sed[[:space:]]+-n|git[[:space:]]+(status|log|diff|show|branch|fetch|rev-parse|add|commit|worktree[[:space:]]+list))([[:space:]]|$)'; then
    log "ALLOW:fast"; exit 0
  fi
fi

# 3) Jev risk classification for everything else.
STATE="$(jq -nc --arg c "$CMD" '{command:$c, context:"Runs from the local control dir ~/pumpwire-control on a Mac. `ssh pw ...` runs on the VPS. Production = ~/pumpwire main checkout, branch main, ~/pumpwire-data/pumpwire.db and pm2 services without a -devnet suffix. Devnet services, card/* and dev branches, ~/wt/* worktrees and ~/pumpwire-devnet are non-production."}')"
OUT="$(cd "$DIR" && JEV_TIMEOUT_MS=4000 node scripts/jev.mjs risk --state "$STATE" 2>/dev/null)"
ACTION="$(printf '%s' "$OUT" | jq -r '.action // "escalate"' 2>/dev/null)"
PICK="$(printf '%s' "$OUT" | jq -r '.pick // ""' 2>/dev/null)"
ERR="$(printf '%s' "$OUT" | jq -r '.error // ""' 2>/dev/null)"

case "$ACTION" in
  allow) log "ALLOW:jev:$PICK"; exit 0 ;;
  deny)  block "jev:$PICK" ;;
  ask)
    if [ -n "$ERR" ] && [ "${GUARD_FAIL_MODE:-open}" = "open" ]; then log "ALLOW:jev-unavailable"; exit 0; fi
    block "jev:needs-approval:${PICK:-unknown}" ;;
  *)
    if [ "${GUARD_FAIL_MODE:-open}" = "open" ]; then log "ALLOW:jev-unavailable"; exit 0; fi
    block "jev-unavailable" ;;
esac

Put the AnsemHack kit here before running bin/pw-sync-vps:
  00-README-START-HERE.md, 01-PWIRE-Product-Spec.md, 02-AnsemHack-Rules-and-Win-Plan.md,
  03-Agent-Org-Setup.md, 04-Master-Prompt-Jev.md, PumpWire-Project-Brief.md, AnsemHack-Clawrena-Hackathon-Info.md
  skills/<name>.SKILL.md  (the 7 skills from the Drive "skills" folder)
Download: Google Drive → "ClawPump AnsemHack (Oct 1 submission)" → Download (zip) → unzip here.
T-001 copies these into the repo as docs/kit/ and .claude/skills/<name>/SKILL.md.

#!/usr/bin/env bash
# ~/pumpwire-runs/run.sh CARD ROLE MODEL TURNS [SESSION_ID]
# Executes ONE card headless in an isolated git worktree (no secrets inside), then leaves
# CARD.json (result), CARD.err, CARD.exit ("<code> <secs>"), CARD.meta ("<role> <model>") and CARD.done.
# Started by bin/pw-dispatch inside a tmux session named after the card.
set -uo pipefail
CARD="$1"; ROLE="$2"; MODEL="$3"; TURNS="$4"; SID="${5:-}"
RUNS="$HOME/pumpwire-runs"; REPO="$HOME/pumpwire"; BASE="${PW_BASE_BRANCH:-dev}"
# Optional: DEEPSEEK_API_KEY / DS_MODEL for the `ds` role (chmod 600). Never read by agents (denied in .claude/settings.json).
if [ -f "$HOME/.pumpwire-agents.env" ]; then set -a; . "$HOME/.pumpwire-agents.env"; set +a; fi

BASECARD="${CARD%-R}"; WT="$HOME/wt/$BASECARD"
echo "$ROLE $MODEL" > "$RUNS/$CARD.meta"
start=$(date +%s); code=0
BRIEF="$(cat "$RUNS/briefs/$CARD.md")"
ROLEP="$(cat "$RUNS/roles/$ROLE.md" 2>/dev/null || true)"
finish() { echo "$code $(( $(date +%s) - start ))" > "$RUNS/$CARD.exit"; touch "$RUNS/$CARD.done"; exit 0; }

case "$ROLE" in
  seller|scout) cd "$HOME/pumpwire-devnet" 2>/dev/null || cd "$HOME" || exit 1 ;;
  *)
    git -C "$REPO" fetch -q origin || true
    if [ ! -d "$WT" ]; then
      if [ "$ROLE" = "reviewer" ]; then
        # Cards built locally by ds-coder only exist as origin/card/<id>: check them out here for review.
        if git -C "$REPO" rev-parse -q --verify "origin/card/$BASECARD" >/dev/null; then
          git -C "$REPO" worktree add -q -B "card/$BASECARD" "$WT" "origin/card/$BASECARD" 2>>"$RUNS/$CARD.err"
        else
          jq -n --arg c "$CARD" '{result: ("HANDOFF " + $c + "\nstatus: blocked\nverdict: BOUNCE\ngaps: no worktree or origin/card branch to review; dispatch the build card first")}' > "$RUNS/$CARD.json"
          code=1; finish
        fi
      else
        git -C "$REPO" worktree add -q -B "card/$BASECARD" "$WT" "origin/$BASE" 2>>"$RUNS/$CARD.err" || { code=1; echo '{"result":"worktree creation failed"}' > "$RUNS/$CARD.json"; finish; }
      fi
    fi
    cd "$WT" || { code=1; echo '{"result":"cannot enter worktree"}' > "$RUNS/$CARD.json"; finish; }
    # Pick up commits pushed from elsewhere (e.g. a local ds-coder fix) without discarding local work.
    git merge -q --ff-only "origin/card/$BASECARD" 2>/dev/null || true
    ;;
esac

RESUME=(); [ -n "$SID" ] && RESUME=(--resume "$SID")
case "$ROLE" in
  architect|builder|reviewer|ops)
    EXTRA=()
    [ "$ROLE" = "ops" ] && EXTRA=(--allowedTools "Bash(pm2:*)" "Bash(caddy:*)" "Bash(crontab:*)" "Bash(curl:*)" "Bash(systemctl status:*)")
    claude "${RESUME[@]}" -p "$BRIEF" --model "$MODEL" --append-system-prompt "$ROLEP" \
      --output-format json --max-turns "$TURNS" --permission-mode acceptEdits "${EXTRA[@]}" \
      > "$RUNS/$CARD.json" 2> "$RUNS/$CARD.err" || code=$?
    ;;
  ds)
    # Claude Code harness, DeepSeek brain (DeepSeek's Anthropic-compatible endpoint). VERIFY base URL + model id before use.
    ANTHROPIC_BASE_URL="${DS_BASE_URL:-https://api.deepseek.com/anthropic}" ANTHROPIC_AUTH_TOKEN="${DEEPSEEK_API_KEY:-}" \
    ANTHROPIC_MODEL="${DS_MODEL:-deepseek-chat}" ANTHROPIC_SMALL_FAST_MODEL="${DS_MODEL:-deepseek-chat}" \
    claude "${RESUME[@]}" -p "$BRIEF" --append-system-prompt "$(cat "$RUNS/roles/builder.md")" \
      --output-format json --max-turns "$TURNS" --permission-mode acceptEdits \
      > "$RUNS/$CARD.json" 2> "$RUNS/$CARD.err" || code=$?
    ;;
  seller|scout)
    SKILLS="clawrena-compliance,pumpwire-mcp"; [ "$ROLE" = "scout" ] && SKILLS="$SKILLS,pumpwire-scout,build-in-public"
    hermes chat -s "$SKILLS" --oneshot -q "$ROLEP

$BRIEF" > "$RUNS/$CARD.txt" 2> "$RUNS/$CARD.err" || code=$?
    jq -Rs '{result: .}' < "$RUNS/$CARD.txt" > "$RUNS/$CARD.json"
    ;;
  *) echo "{\"result\":\"unknown role $ROLE\"}" > "$RUNS/$CARD.json"; code=1 ;;
esac

# The runner, not the model, pushes the card branch so reviewers and the Principal can see it.
case "$ROLE" in architect|builder|ops|ds) git -C "$WT" push -q -u origin "card/$BASECARD" 2>>"$RUNS/$CARD.err" || true ;; esac
finish

# FACTS (semantic memory)
<!-- - [VERIFIED|VERIFY] <fact> — <source> — <date checked>. Researcher/scribe add lines; VERIFY lines must be resolved before mainnet use. -->

## Hackathon + token
- [VERIFIED] Entry: PumpWire / $PWIRE on ClawPump, X @Josefusan111, track ClawPump × pump.fun (+ Overall Winner) — kit 00 — 2026-09-30
- [VERIFIED] Judging window Sep 28 – Oct 7; winners Oct 8 — kit 02 — 2026-09-30
- [VERIFIED] Judged on: product/novel tooling on Hermes harness, onchain volume, $ANSEM volume, builders onboarded, attention, deploy early — kit 02 §C — 2026-09-30

## Product constants
- [VERIFIED] Prices: rug_risk_score $0.01 · deployer_history $0.02 · early_buyer_map $0.05 · deployer_alerts $0.01/alert — kit 01 — 2026-09-30
- [VERIFIED] Verdicts: 0–24 LOW · 25–49 MED · 50–74 HIGH · 75–100 EXTREME — kit 01 — 2026-09-30
- [VERIFIED] Score v0 weights: deployer history 25 · bundled launch 20 · holder concentration 15 · dev position 10 · fresh-wallet ratio 10 · funding cluster 10 · curve velocity 5 · metadata flags 5 — kit 01 — 2026-09-30
- [VERIFIED] Scout caps: ≤ $0.05 per call, ≤ $5 per day; first-party calls labeled on /live — kit 03 — 2026-09-30
- [VERIFY] payTo candidate: PumpWire agent wallet 6TeXC9ay1RBHE2QasADUScD1865ZKfmePFt8wkQLc8Se — kit 01 — Mises confirms in A-001

## Chain + payments (researcher resolves in T-003)
- [VERIFY] USDC mainnet mint EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v — common knowledge — confirm on Solscan
- [VERIFY] USDC devnet mint (Circle) 4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU — common knowledge — confirm
- [VERIFY] $ANSEM mint — unknown
- [VERIFY] x402 packages named in kit: @x402/express, @x402/fetch — confirm exact names/versions and Solana `exact` scheme support
- [VERIFY] x402 facilitator URLs (devnet, mainnet) and whether arbitrary SPL tokens ($ANSEM) are accepted
- [VERIFY] PumpPortal WebSocket URL and subscribe methods (new tokens, token trades)
- [VERIFY] Helius endpoints for funding source / enhanced transactions and the plan's rate limits

## ClawPump / Hermes
- [VERIFY] ClawPump public launchpad MCP https://clawpump.tech/api/mcp (kit 03) vs https://mcp.clawpump.tech/mcp (claw-agent README) — which is current
- [VERIFIED] ClawPump Agent MCP for Claude Code: `npx @clawpump/agents --claude` with a cpk_ key from clawpump.tech/dashboard/api — kit 03 — 2026-09-30
- [VERIFIED] Hermes one-shot: `hermes chat -q "<prompt>"` (also `--oneshot`, `hermes -z`); preload skills `-s a,b`; skills dir ~/.hermes/skills — Hermes CLI docs — 2026-09-30

## Tooling
- [VERIFIED] Jev: model `typesafe-ai/jev`, POST https://ai-gateway.vercel.sh/v1/evaluate, `Authorization: Bearer $AI_GATEWAY_API_KEY`, question types boolean/choice/score, ~$0.042 per 1M input tokens, output free, median ~0.35 s — Vercel AI Gateway docs + launch coverage — 2026-09-30
- [VERIFIED] Command Code: project memory AGENTS.md; subagents `.commandcode/agents/*.md`; skills `.commandcode/skills/<name>/SKILL.md`; hooks in `.commandcode/settings.json` (PreToolUse/PostToolUse/Stop/SessionStart; exit 2 blocks); headless `cmd -p`, `--continue`, `--resume` — commandcode.ai docs — 2026-09-30
- [VERIFY] DeepSeek Anthropic-compatible endpoint https://api.deepseek.com/anthropic + current model id (for the VPS `ds` role)
- [VERIFIED] VPS: Contabo, Ubuntu 24.04, user joseph, ssh alias `pw` — Mises — 2026-09-30

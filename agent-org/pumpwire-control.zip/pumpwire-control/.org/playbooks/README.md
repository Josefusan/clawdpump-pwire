# Playbooks (procedural memory)

A playbook is written the first time a procedure works; it becomes a skill patch after it is reused successfully a second time (skill memory-ops §Consolidation).

Format (≤ 30 lines):
```
# <verb-object>, e.g. deploy-devnet-api
when: <trigger>
steps:
1. <command>
2. <command>
verify: <command + expected output>
gotchas: <what bit us, with episode ids>
last used: <date> · uses: <n>
```

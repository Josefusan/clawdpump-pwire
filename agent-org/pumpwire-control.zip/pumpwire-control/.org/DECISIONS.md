# DECISIONS (ADR-lite, append-only, owner: Principal)
<!-- D-xxx <date> <decision> — why — who. Architect ADRs live in repo docs/adr/ and are indexed here. -->

- D-001 2026-09-30 Secrets move out of the repo: `~/.config/pumpwire/{devnet,mainnet}.env` (chmod 600), loaded with `node --env-file`. Live DB at `~/pumpwire-data/pumpwire.db` (+ hourly `snapshot.db`), shared by devnet and mainnet services. Card worktrees live in `~/wt/` and contain no secrets. — so agents can build and test without ever being near keys — Mises/Principal. (Supersedes the `.env`-in-repo and `~/pumpwire/data/` paths in kit 03.)
- D-002 2026-09-30 "Jev" now means the TypeSafe decision model (`typesafe-ai/jev`); the orchestrator is renamed Principal. — Jev returns typed decisions, it cannot write plans or code — Mises.
- D-003 2026-09-30 Principal = Command Code (DeepSeek) on the Mac; feature code = Claude Code headless on the VPS, one worktree per card; bulk = local DeepSeek subagents; runtime agents = Hermes. — cost routing + isolation — Mises.
- D-004 2026-09-30 Branches: `card/T-xxx` → `dev` (Principal, after review) → `main` (Mises at G4). — speed without losing the human gate on prod — Mises.
- D-005 2026-09-30 Mainnet target moved from Sat Oct 3 23:59 to Thu Oct 1 12:00 CT (24 h sprint); stretch ships Oct 2–6. — every day live counts for judging — Mises.
- D-006 2026-09-30 Mises runs every money, mainnet and public command himself from `.org/APPROVALS.md`; agents prepare exact commands. — keeps signing and publishing human — Mises.

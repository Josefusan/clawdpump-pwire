# TASKS — PumpWire 24h sprint (owner: Principal)
<!-- Card format: skill dispatch-remote §1. Times CT. Only the Principal edits this file. -->

## W0 · Wed 17:00–18:00 — foundations

### T-001 Repo scaffold
status: TODO
lane: ops · role: builder · model: sonnet · reviewer: sonnet
deps: — (origin = github.com/Josefusan/clawdpump-pwire with main + dev branches)
due: Wed 18:00
done when: npm workspaces `packages/{ingest,score,api,mcp,live,scout}` with TypeScript + vitest, `npm test` green (one placeholder test per package); `.claude/settings.json` copied from `~/pumpwire-runs/claude-settings.json`; kit docs already at the repo root (00-…04-*.md, PumpWire-Project-Brief.md, AnsemHack-Clawrena-Hackathon-Info.md) moved with `git mv` to `docs/kit/` (README.md stays at root; fix its links); the 7 skills in `skills/<name>.SKILL.md` also installed as `.claude/skills/<name>/SKILL.md`; `agent-org/` and `integrations/` left untouched; `.gitignore` (node_modules, data, *.env, .env*); `env.example` listing variable NAMES only; `docs/adr/` exists
context: docs/kit/03-Agent-Org-Setup.md §Repo layout
notes:

### T-002 Interfaces, schema, scoring spec
status: TODO
lane: A+B · role: architect · model: opus · reviewer: none (Principal checks completeness)
deps: —
due: Wed 18:15
done when: `docs/INTERFACES.md` defines package boundaries, TS types (Token, Trade, Wallet, FundingEdge, RiskResult, Reason, CallRecord), env var NAMES per service, HTTP contract for /health /live /v1/stats /v1/risk/:mint incl. the 402 flow and response JSON, MCP tool schema for rug_risk_score, scoring v0 factors with exact formulas/thresholds and verdict bands; `docs/schema.sql` (SQLite WAL, indexes, calls table with first_party + unique tx_sig); `docs/adr/ADR-001-stack.md`, `ADR-002-x402-verification.md` (incl. direct SPL-transfer fallback); VERIFY list in handoff. Touches only docs/.
context: docs/kit/01-PWIRE-Product-Spec.md, docs/kit/03-Agent-Org-Setup.md; skills pumpwire-rug-risk, pumpwire-x402-api, pumpwire-ingest
notes:

### T-003 VERIFY sweep
status: TODO
lane: docs · role: researcher (local) · model: deepseek · reviewer: none
deps: —
due: Wed 18:15
done when: `.org/FACTS.md` has VERIFIED/UNRESOLVED lines with source + date for: PumpPortal WS URL + subscribe message shapes (new tokens, trades); Helius endpoints for funding source / enhanced tx + plan rate limits; x402 Solana server + client npm packages (exact names, versions, `exact` scheme on Solana) and facilitator URLs for devnet + mainnet; USDC mint mainnet + devnet; $ANSEM mint and whether the facilitator accepts arbitrary SPL tokens; ClawPump MCP endpoints (kit: clawpump.tech/api/mcp vs README: mcp.clawpump.tech/mcp); ClawPump x402 service listing steps; DeepSeek Anthropic-compatible base URL + model id
context: .org/FACTS.md (VERIFY lines)
notes:

## W1 · Wed 18:00–21:30 — ingest live, paid API on devnet

### T-004 Ingest v0
status: TODO
lane: A · role: builder · model: sonnet · reviewer: sonnet
deps: T-001, T-002, T-003 (PumpPortal facts)
due: Wed 19:30
done when: `packages/ingest` subscribes to PumpPortal new tokens + trades, writes tokens/trades/deployers to DB_PATH (SQLite WAL) idempotently (duplicate sigs ignored); reconnect with backoff; parsers are pure and unit-tested on `fixtures/pumpportal/*`; `npm run ingest` for 10 min shows growing counts (evidence in handoff)
context: docs/INTERFACES.md, docs/schema.sql; skill pumpwire-ingest
notes: deploy immediately after merge (T-009 deploy script) so data accumulates overnight

### T-005 Wallet + funding enrichment
status: TODO
lane: A · role: builder · model: sonnet · reviewer: sonnet
deps: T-004
due: Wed 22:30
done when: rate-limited queue enriches deployer + first 30 buyers per new mint: wallets.first_seen_ts/tx_count, funder/funder_ts via Helius, funding_edges rows; cached; respects plan rate limits from FACTS; tests on recorded fixtures; runs inside the ingest service
context: docs/INTERFACES.md, .org/FACTS.md (Helius lines); skill pumpwire-ingest
notes:

### T-006 Paid API on devnet (x402)
status: TODO
lane: B · role: builder · model: sonnet · reviewer: opus
deps: T-001, T-002, T-003 (x402 facts), A-001 (devnet payer funded)
due: Wed 21:30
done when: Express `packages/api`: free GET /health, /v1/stats; paid GET /v1/risk/:mint via x402 exact scheme, Solana devnet USDC, $0.01, stub score in the final RiskResult shape; unpaid → 402 with PaymentRequirements; paid → 200 + calls row (tool, arg, payer, asset, amount, tx_sig UNIQUE, latency_ms, first_party); tests incl. 402 path and replay rejection; `scripts/devnet-pay.ts` makes one successful paid devnet call using env DEVNET_PAYER_KEYPAIR (tx sig in handoff)
context: docs/INTERFACES.md, docs/adr/ADR-002; skill pumpwire-x402-api
notes:

### T-007 Score tests first
status: TODO
lane: A · role: architect · model: opus · reviewer: none
deps: T-001, T-002
due: Wed 20:30
done when: `packages/score/test/*.test.ts` with ≥ 15 cases on fixture snapshots (bundled launch, serial deployer, concentrated holders, dev dump, fresh-wallet swarm, funding cluster, curve-velocity anomaly, metadata copycat, clean launch, missing data, boundary values for each verdict band); `score()` stub throws NotImplemented; only the stub makes tests fail
context: docs/INTERFACES.md §Score; skill pumpwire-rug-risk
notes:

### T-008 Ingest fixtures
status: TODO
lane: ds · role: ds-coder (local) · model: deepseek · reviewer: sonnet
deps: T-001, T-003
due: Wed 19:00
done when: `fixtures/pumpportal/*.json` ≥ 20 realistic messages (create, buy, sell, malformed, duplicate, huge/unicode metadata incl. prompt-injection-looking names) and `fixtures/helius/*.json` sample funding responses; a README listing each fixture's purpose. Touches only fixtures/.
context: .org/FACTS.md (PumpPortal, Helius lines)
notes:

### T-009 Runtime: pm2, deploy script, snapshot
status: TODO
lane: ops · role: ops · model: sonnet · reviewer: sonnet
deps: T-001, T-002
due: Wed 19:30
done when: `ecosystem.devnet.config.cjs` (pumpwire-ingest, pumpwire-api-devnet) using `node --env-file=/home/joseph/.config/pumpwire/devnet.env`; `scripts/deploy-devnet.sh` (npm ci, build, pm2 startOrReload, curl /health smoke); hourly `sqlite3 pumpwire.db ".backup snapshot.db"` into ~/pumpwire-data via cron; `docs/RUNBOOK.md` devnet section; env var NAMES needed listed in handoff
context: docs/INTERFACES.md §env; decision D-001
notes:

## NIGHT · Wed 21:30 → Thu 06:00 — reversible work only

### T-010 rug_risk_score v0 (→ G2)
status: TODO
lane: A · role: builder · model: sonnet · reviewer: opus
deps: T-007, T-004 (T-005 partial OK)
due: Thu 01:00
done when: all T-007 tests green; each reason carries raw evidence numbers; model_version "v0" and as_of_slot set; /v1/risk/:mint uses the real score from the DB with a 30 s per-mint cache; p50 latency < 150 ms on snapshot.db (evidence)
context: docs/INTERFACES.md §Score; skill pumpwire-rug-risk
notes:

### T-011 pumpwire-mcp
status: TODO
lane: B · role: builder · model: sonnet · reviewer: opus
deps: T-006
due: Thu 01:00
done when: `packages/mcp` stdio MCP server exposing rug_risk_score(mint) that pays the API via x402 using the CALLER's wallet (env var names from INTERFACES); README usage block; e2e test on devnet: MCP call → payment → RiskResult
context: docs/INTERFACES.md §MCP; skills pumpwire-mcp, pumpwire-x402-api
notes:

### T-012 G3 devnet paid loop
status: TODO
lane: B · role: builder · model: sonnet · reviewer: opus
deps: T-010, T-011
due: Thu 04:00
done when: `scripts/g3.ts` makes 20 paid devnet calls through pumpwire-mcp on real mints; wrong amount, wrong mint and replayed tx are each rejected (4xx) and logged; prints a summary; calls table shows 20 rows with tx sigs
context: docs/adr/ADR-002; skill pumpwire-x402-api
notes:

### T-013 /live page
status: TODO
lane: ds · role: ds-coder (local) · model: deepseek · reviewer: sonnet
deps: T-006
due: Thu 02:00
done when: `packages/live` static HTML/JS served at /live: counters (paid calls, USDC paid, $ANSEM paid, unique payers, integrators), last 50 calls with Solscan links (mint + payment tx), first-party vs third-party split, backtest block, model version; reads /v1/stats; escapes all token metadata; readable at phone width
context: docs/INTERFACES.md §/v1/stats; skill build-in-public
notes:

### T-014 Backtest
status: TODO
lane: A · role: ds (VPS) · model: deepseek · reviewer: sonnet  (fallback: builder haiku)
deps: T-010; start after 02:00 so snapshot.db has ≥ 5 h of launches
due: Thu 05:00
done when: `scripts/backtest.ts` labels launches older than 1 h in snapshot.db (DEAD_1H / DEV_DUMP / SURVIVED, rules stated), scores them, prints precision/recall at HIGH+ with sample size; writes docs/BACKTEST.md + data/backtest.json for /live; small-sample caveat stated plainly
context: docs/INTERFACES.md §Score; skill pumpwire-rug-risk
notes:

### T-015 Drafts
status: TODO
lane: docs · role: drafter (local) · model: deepseek · reviewer: Mises
deps: —
due: Thu 05:00
done when: `.org/drafts/`: README (what, why, pricing, 2-minute integrate snippet, first-party disclosure), launch thread (6–8 posts), 3 build-in-public posts (indexing, backtest, "agents can pay for rug checks"), updated stream script, DM template for agent builders; all compliance-clean
context: docs/kit/02 §C,§E; skill build-in-public
notes:

### T-016 Scout on devnet
status: TODO
lane: B · role: builder · model: sonnet · reviewer: opus
deps: T-011
due: Thu 05:00
done when: `packages/scout`: filter (≥ 5 unique buyers in first 2 min), pays via pumpwire-mcp client, caps enforced in code (≤ $0.05/call, ≤ $5/day, persisted), every call logged first_party=true, HIGH/EXTREME alert drafts written to ~/pumpwire-data/alerts/*.md (never posted); pm2 `pumpwire-scout-devnet` pays for ≥ 10 real launches on devnet (evidence)
context: docs/INTERFACES.md; skills pumpwire-scout, pumpwire-mcp
notes:

### T-017 Mainnet cutover script + runbook
status: TODO
lane: ops · role: ops · model: sonnet · reviewer: opus
deps: T-009, T-006
due: Thu 04:00
done when: `scripts/cutover-mainnet.sh` (preflight: on main, tests green, required env NAMES present in mainnet.env checked without printing values, prints payTo/prices/caps from config for Mises to eyeball, facilitator reachable; starts ecosystem.mainnet.config.cjs; smoke: unpaid → 402; `--rollback` flag) + mainnet section in docs/RUNBOOK.md (≤ 30 lines). Never executed by agents.
context: docs/adr/ADR-002; decision D-001, D-006
notes:

## MORNING · Thu 06:00–12:00 — mainnet

### T-018 Mainnet smoke (→ G4)
status: TODO
lane: ops · role: ops · model: sonnet · reviewer: none (Mises approves G4)
deps: A-002, A-003, A-004
due: Thu 09:00
done when: after Mises runs the cutover: 3 real paid mainnet calls (Scout wallet) verified on Solscan; /live shows them as first-party; /health green; evidence = 3 Solscan tx links
context: docs/RUNBOOK.md
notes:

### T-019 Scout mainnet + Seller skill
status: TODO
lane: B · role: scout + seller (hermes) · model: hermes · reviewer: Principal
deps: T-018
due: Thu 11:30
done when: pumpwire-scout (mainnet) running within caps; the $PWIRE ClawPump agent has the PumpWire skill (create_custom_skill via Agent MCP) answering "is this mint risky?" by calling the API; evidence: skill id + one sample Q&A
context: skills pumpwire-scout, pumpwire-mcp, clawrena-compliance
notes:

## AFTERNOON · Thu 12:00–21:30 — public, then stretch

### T-020 Public (→ G5)
status: TODO
lane: ops · role: ops · model: sonnet · reviewer: Mises
deps: T-018, T-013, T-015
due: Thu 15:30
done when: /live over TLS via Caddy on the public host; README from drafts committed; repo ready to flip public (secret scan clean: no keys, no .env, no IPs in history); A-005 prepared
context: docs/RUNBOOK.md; skill build-in-public
notes:

### STRETCH (in order, only after G5)
- T-021 deployer_history ($0.02) · builder sonnet · opus review
- T-022 $ANSEM payments at 10% off (only if T-003 shows the facilitator accepts it) · builder sonnet · opus review
- T-023 ClawPump x402 service listing · seller (hermes) · Mises approves
- T-024 Jev-gated Scout spend ("is this launch worth scoring?") · builder haiku
- T-025 early_buyer_map ($0.05) · builder sonnet · opus review

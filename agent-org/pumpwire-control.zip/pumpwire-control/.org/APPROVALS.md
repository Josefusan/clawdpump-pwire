# APPROVALS — things only Mises does
<!-- The Principal writes entries. Mises runs the commands himself and changes `status:` to DONE or REJECTED (with a note).
     Batches: Wed 21:15 (pre-sleep) · Thu 06:00 · Thu 11:00 · Thu 15:30 -->

## A-001 · Sprint setup · needed by Wed 18:30 CT
why: T-006/T-009 need devnet secrets and a funded devnet payer; the `ds` role needs a DeepSeek key on the VPS.
do (on the VPS, as joseph):
1. Confirm payTo for devnet and mainnet (kit candidate: PumpWire agent wallet `6TeXC9ay1RBHE2QasADUScD1865ZKfmePFt8wkQLc8Se`, or a dedicated revenue wallet). Reply with the address(es).
2. Devnet payer: `mkdir -p ~/pumpwire-devnet-wallet && solana-keygen new --no-bip39-passphrase -o ~/pumpwire-devnet-wallet/payer.json`, then `solana airdrop 2 $(solana-keygen pubkey ~/pumpwire-devnet-wallet/payer.json) --url devnet` and devnet USDC from Circle's faucet.
3. `mkdir -p ~/.config/pumpwire && chmod 700 ~/.config/pumpwire`, create `~/.config/pumpwire/devnet.env` (chmod 600) with at least: `HELIUS_API_KEY=` `PAYTO_ADDRESS=` `DEVNET_PAYER_KEYPAIR=/home/joseph/pumpwire-devnet-wallet/payer.json` `DB_PATH=/home/joseph/pumpwire-data/pumpwire.db` (+ any names T-002/T-009 add).
4. Optional for the `ds` role: `~/.pumpwire-agents.env` (chmod 600) with `DEEPSEEK_API_KEY=` and `DS_MODEL=`.
status: PENDING

## A-002 · G4 mainnet parameters · needed by Thu 06:30 CT
why: mainnet go-live.
decide: payTo (mainnet), price rug_risk_score = $0.01 USDC, Scout caps $0.05/call and $5/day, facilitator URL (from FACTS, VERIFIED), then create `~/.config/pumpwire/mainnet.env` (chmod 600).
status: PENDING

## A-003 · Merge dev → main and run the cutover · Thu ~07:00 CT
run (VPS): `cd ~/pumpwire && git fetch origin && git checkout main && git merge --ff-only origin/dev && git push origin main && bash scripts/cutover-mainnet.sh`
status: PENDING

## A-004 · Fund the Scout mainnet wallet (≤ $5 USDC + fee SOL) · Thu ~07:30 CT
status: PENDING

## A-005 · Go public (G5) · Thu ~15:30 CT
do: make the repo public, share the /live URL, post the launch thread from `.org/drafts/` (edit freely).
status: PENDING
